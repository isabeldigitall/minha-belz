---
name: belz-mentoradas
description: BELZ MENTORADAS — Guia a aluna a criar a propria assistente pessoal Telegram (estilo Belz da Isabel) do zero, no proprio ambiente dela. Setup completo passo a passo: Google Cloud project, OAuth Calendar+Drive, Gemini API com billing, bot Telegram via BotFather, deploy local no PC ou em VPS. A Belz gere agenda, lembretes, voz E organiza documentos no Drive (le faturas/recibos por foto ou PDF e arruma por categorias que a aluna escolhe). Cada aluna fica com a SUA assistente, com o SEU codigo, com a SUA conta Google, com o SEU bot. Use quando a mentorada/aluna pedir "criar a minha assistente", "minha belz", "assistente telegram", "bot telegram pessoal", "agenda no telegram", "organizar documentos no telegram", "belz que organiza faturas", "ter uma belz como a isabel", ou variantes.
---

# BELZ MENTORADAS — Setup da Assistente Pessoal

A tua mentorada vai ter a propria assistente pessoal a correr no Telegram dela, com o Google Calendar dela, a marcar eventos e a enviar lembretes — exatamente como a Belz da Isabel.

**O QUE A SKILL FAZ:** conduz a aluna por 9 fases interativas. Em cada fase, da instrucoes claras (com URLs e prints), espera que ela faca, recebe o output (token, key, etc) e avanca. No fim, a Belz dela esta a correr.

**REGRA DE OURO:** UMA pergunta de cada vez. Espera resposta. So depois passa a seguinte. Nunca despejar 3 passos juntos. A aluna nao e tecnica — fala de forma clara, paciente e amiga.

---

## FASE 0 — Boas-vindas e diagnostico

Diz exatamente:

> Ola! Vamos criar a tua propria assistente pessoal no Telegram, igual a Belz da Isabel. No fim, vais poder dizer-lhe coisas como "marca reuniao com a Maria amanha as 15h" ou "lembra-me de pagar a luz na sexta" — por texto ou audio — e ela trata de tudo no teu Google Calendar.
>
> O setup demora cerca de 30 minutos e tens de fazer alguns passos no browser. Vou guiar-te passo a passo.
>
> Primeiro, preciso de saber: **onde queres que a tua Belz corra?**
>
> **(1) No teu PC/Mac** — gratis, mas a Belz so responde quando o computador esta ligado e a Belz a correr. Bom para experimentar.
>
> **(2) Numa VPS (servidor sempre ligado)** — ~5€/mes, a Belz responde 24/7 mesmo com o teu PC desligado. Bom para uso a serio. Precisas de uma conta Hostinger ou similar.
>
> Diz-me 1 ou 2.

Espera resposta. Guarda a escolha em memoria interna como `DEPLOY_TARGET` (`pc` ou `vps`).

Se for **VPS**, pergunta tambem:

> Otimo! Para a VPS preciso de saber:
>
> - Tens ja uma VPS Hostinger (ou outra) com acesso SSH? (sim/nao)
> - Se sim, qual o IP e tens a chave SSH configurada?

Se a aluna **nao tem VPS**, sugere:

- Hostinger VPS KVM 1 (~5€/mes) — https://www.hostinger.com/vps-hosting
- Alternativa gratuita inicial: usar o PC e migrar depois

---

## FASE 1 — Pre-requisitos

Diz:

> Antes de comecarmos, confirma que tens:
>
> 1. **Conta Google** (Gmail ou Workspace) — a que vai ter o Calendar/Drive da tua Belz
> 2. **Telegram instalado** no telemovel
> 3. **Cartao de credito ou debito** — vai ser usado para ativar a faturacao no Google Cloud (necessario para a IA Gemini funcionar bem). O custo real e cerca de 0,50€-2€ por mes.
> 4. **Node.js 20 ou superior** instalado no computador
>
> Tens tudo? (sim/nao — se nao, diz-me o que falta)

Espera. Se faltar Node.js, da link: https://nodejs.org/en/download

Se a aluna pergunta porque precisa de cartao: explica que o Google da gratis para sempre uma boa quota, mas exige cartao para verificar identidade. Sem billing, a Gemini gratis so da 20 pedidos/dia e a Belz para de funcionar em minutos.

---

## FASE 2 — Criar projeto no Google Cloud

Diz:

> Vamos criar um projeto no Google Cloud. E onde vivem as credenciais da Belz para aceder ao teu Calendar.
>
> 1. Abre: https://console.cloud.google.com/projectcreate
> 2. **Nome do projeto:** `minha-belz` (ou o que quiseres)
> 3. **Organizacao:** deixa em branco
> 4. Clica **Criar**
> 5. Espera ~30 segundos ate o projeto ser criado
> 6. **CRITICO:** no topo da pagina, certifica-te que esta selecionado o projeto que acabaste de criar (clica no nome do projeto se nao estiver)
>
> Diz-me quando estiver feito.

Espera "feito" / "ok" / "pronto".

---

## FASE 3 — Ativar billing (faturacao)

Diz:

> Agora vamos ativar a faturacao. Sem isto, a Gemini nao funciona bem.
>
> 1. Abre: https://console.cloud.google.com/billing
> 2. Se nao tens conta de faturacao, clica **CRIAR CONTA**
> 3. Preenche os teus dados e o cartao
> 4. Depois volta ao projeto `minha-belz`: https://console.cloud.google.com/billing/linkedaccount
> 5. Liga a conta de faturacao ao projeto `minha-belz`
>
> Nota: O Google da-te ~250€ de credito gratuito nos primeiros 90 dias. Depois disso, o custo real da Belz e baixissimo (cerca de 0,50€-2€/mes).
>
> Diz-me quando a faturacao estiver ligada ao projeto.

Espera confirmacao.

---

## FASE 4 — Ativar APIs (Calendar, Drive, Gemini)

Diz:

> Agora vamos ativar 3 servicos no teu projeto:
>
> **Servico 1 — Google Calendar:**
> Abre: https://console.cloud.google.com/apis/library/calendar-json.googleapis.com
> Confirma que esta selecionado o projeto `minha-belz` no topo, clica **ATIVAR** e espera.
>
> Diz-me quando estiver ativado.

Espera. Depois:

> **Servico 2 — Google Drive:**
> Abre: https://console.cloud.google.com/apis/library/drive.googleapis.com
> Clica **ATIVAR**.
>
> Diz-me quando estiver feito.

Espera. Depois:

> **Servico 3 — Gemini API (IA):**
> Abre: https://console.cloud.google.com/apis/library/generativelanguage.googleapis.com
> Clica **ATIVAR**.
>
> Diz-me quando estiver feito.

Espera confirmacao.

---

## FASE 5 — OAuth Consent Screen

Diz:

> Agora vamos configurar o ecra de consentimento — e o que aparece quando a Belz te pede acesso ao Calendar.
>
> 1. Abre: https://console.cloud.google.com/auth/overview
> 2. Se aparecer **GET STARTED** ou **COMECAR**, clica
> 3. **App name:** Minha Belz
> 4. **User support email:** o teu email
> 5. **Audience:** escolhe **External** (Externo)
> 6. **Developer contact info:** o teu email
> 7. Clica **CRIAR**
>
> Depois vai a https://console.cloud.google.com/auth/audience e:
>
> - Clica **+ ADD USERS** (Adicionar utilizadores)
> - Adiciona o teu email Google (o mesmo que vais usar para a Belz)
> - Guardar
>
> Diz-me quando estiver feito.

Espera confirmacao.

---

## FASE 6 — Criar OAuth Credentials

Diz:

> Agora vamos criar as credenciais OAuth — o "passe" que a Belz vai usar.
>
> 1. Abre: https://console.cloud.google.com/auth/clients
> 2. Clica **+ CREATE CLIENT** (Criar cliente)
> 3. **Application type:** Desktop app (Aplicacao de ambiente de trabalho)
> 4. **Name:** Belz Desktop
> 5. Clica **CRIAR**
> 6. Aparece um popup com **Client ID** e **Client Secret**
> 7. Copia os DOIS valores e cola-os aqui na nossa conversa, no formato:
>
> ```
> CLIENT_ID: 123456789-xxxxxxx.apps.googleusercontent.com
> CLIENT_SECRET: GOCSPX-xxxxxxxxxxxx
> ```

Espera. **GUARDA INTERNAMENTE** os valores como `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET`.

---

## FASE 7 — Criar Gemini API Key

Diz:

> Agora a chave para a IA Gemini.
>
> 1. Abre: https://aistudio.google.com/apikey
> 2. Clica **Create API key** (Criar chave de API)
> 3. **CRITICO:** quando perguntar o projeto, escolhe `minha-belz` (o que criamos com billing). NAO escolhas outro projeto.
> 4. Copia a key (comeca por `AIza...`)
> 5. Cola-a aqui:
>
> ```
> GEMINI_KEY: AIzaXXXXXXXXXX...
> ```

Espera. **GUARDA** como `GEMINI_API_KEY`.

---

## FASE 8 — Criar Bot no Telegram

Diz:

> Agora vamos criar o bot no Telegram.
>
> 1. Abre o Telegram no telemovel ou em https://web.telegram.org
> 2. Procura por **@BotFather** (com o tick azul)
> 3. Envia: `/newbot`
> 4. **Nome do bot:** algo como "A minha Belz" (pode ter espacos)
> 5. **Username do bot:** tem de terminar em `_bot`. Exemplo: `belz_da_maria_bot`
> 6. O BotFather responde com um TOKEN (algo como `8730093292:AAGbQhYWaR_xJuMsLhkVsddHrxU5QXDyH7E`)
> 7. Cola o token aqui:
>
> ```
> TELEGRAM_TOKEN: 8730093292:AAGbXXXXX...
> ```

Espera. **GUARDA** como `TELEGRAM_BOT_TOKEN`.

Pergunta tambem:

> E mais 3 coisas rapidas:
>
> - Como queres que a Belz te trate? (ex: Maria, Joana...)
> - Qual o teu email Google? (o que adicionaste como Test User)
> - A que horas queres receber o briefing matinal? (numero de 0 a 23 — ex: 8)

Guarda como `OWNER_NAME`, `GOOGLE_EMAIL`, `BRIEFING_HOUR`.

Tambem deteta o timezone do user:

```bash
date +%Z
```

Se o output nao for util, pergunta:

> Em que pais estas? (PT, BR, US-East...)

Mapeia para timezone:

- PT → Europe/Lisbon
- BR → America/Sao_Paulo
- US-East → America/New_York
- UK → Europe/London

Guarda como `TIMEZONE`.

---

## FASE 9 — Instalar e arrancar a Belz

### Caminho A — PC LOCAL

Se `DEPLOY_TARGET = pc`:

```bash
cd ~ && git clone https://github.com/isabeldigitall/minha-belz.git && cd minha-belz && npm install
```

Depois cria o `.env` com Write tool:

```
OWNER_NAME=<OWNER_NAME>
TELEGRAM_BOT_TOKEN=<TELEGRAM_BOT_TOKEN>
GEMINI_API_KEY=<GEMINI_API_KEY>
GOOGLE_CLIENT_ID=<GOOGLE_CLIENT_ID>
GOOGLE_CLIENT_SECRET=<GOOGLE_CLIENT_SECRET>
GOOGLE_EMAIL=<GOOGLE_EMAIL>
TIMEZONE=<TIMEZONE>
BRIEFING_HOUR=<BRIEFING_HOUR>
PORT=3000
```

Diz a aluna:

> A Belz esta instalada! Agora vamos autenticar com a tua conta Google.
>
> Vou correr o setup — vai abrir o browser e tu autorizas o acesso ao teu Calendar e Drive.

Corre:

```bash
cd ~/minha-belz && npm run setup
```

(Background OK. Browser abre automaticamente.)

> No browser:
>
> 1. Faz login com o teu email Google (o mesmo que adicionaste como Test User)
> 2. Se aparecer **"App nao verificada"** → clica **Avancado** → **Continuar para Minha Belz (nao seguro)**. Esta seguro — e a tua propria app, ainda nao foi submetida ao Google para verificacao.
> 3. Aceita os 3 acessos (Calendar, Drive, Email)
> 4. Voltas a uma pagina que diz "Tudo certo!"
>
> Diz-me quando terminares.

Espera. Depois:

> Otimo! Agora vamos arrancar a Belz:

```bash
cd ~/minha-belz && npm start
```

(Em background, com `run_in_background=true`. Captura PID.)

> A Belz esta a correr!
>
> **Ultimo passo:** abre o Telegram, procura o teu bot pelo username (`@belz_da_maria_bot`) e envia `/start`.
>
> Diz-me quando enviares — para confirmar que esta tudo a funcionar.

Espera. Depois confirma sucesso e da dicas:

> A tua Belz esta viva!
>
> Experimenta:
>
> - "O que tenho amanha?"
> - "Marca reuniao com a Maria sexta as 14h"
> - "Lembra-me de comprar pao amanha as 9h"
> - Audios funcionam igual a texto!
>
> **IMPORTANTE:** A Belz so funciona enquanto o teu PC estiver ligado e o `npm start` a correr. Se fechares o terminal, ela para.
>
> Para ela responder sempre (mesmo com PC desligado), considera passar para uma VPS. Diz-me se quiseres ajuda com isso.

### Caminho B — VPS

Se `DEPLOY_TARGET = vps`:

Pede o IP e user SSH se ainda nao tens.

```bash
ssh root@<IP> "apt update && apt install -y nodejs npm git && npm install -g pm2 && cd /root && git clone https://github.com/isabeldigitall/minha-belz.git"
```

Cria o `.env` localmente, depois envia para a VPS:

```bash
scp /tmp/belz.env root@<IP>:/root/minha-belz/.env
```

Para o OAuth na VPS, e mais complicado porque a VPS nao tem browser. Diz a aluna:

> Para autenticar a Google numa VPS, fazemos um truque:
>
> 1. Geras o token AQUI no teu PC (com o `setup-oauth.js` em modo local, com as MESMAS credentials)
> 2. Copiamos o `oauth-token.json` para a VPS
>
> Vou explicar com calma.

Faz primeiro o setup local (Caminho A, npm run setup) so para gerar o token. Depois:

```bash
scp ~/minha-belz/oauth-token.json root@<IP>:/root/minha-belz/oauth-token.json
ssh root@<IP> "cd /root/minha-belz && npm install && pm2 start server.js --name belz && pm2 save && pm2 startup systemd -u root --hp /root | tail -1 | bash"
```

Verifica:

```bash
ssh root@<IP> "pm2 logs belz --lines 20 --nostream"
```

Depois diz a aluna para abrir o Telegram, procurar o bot e enviar `/start`.

---

## FASE 10 — Validacao e celebracao

Quando a aluna confirmar que recebeu resposta no Telegram:

> Conseguiste! A tua Belz esta a funcionar.
>
> Resumo do que tens agora:
>
> - Bot Telegram: `@<username_bot>`
> - Codigo: `~/minha-belz/`
> - Configuracoes: `.env`
> - Token Google: `oauth-token.json`
>
> **Comandos uteis:**
>
> - Parar a Belz: `Ctrl+C` no terminal (PC) ou `ssh root@<IP> "pm2 stop belz"` (VPS)
> - Arrancar de novo: `cd ~/minha-belz && npm start` (PC) ou `pm2 restart belz` (VPS)
> - Ver logs: aparecem no terminal (PC) ou `pm2 logs belz` (VPS)
>
> **Backup importante:** o `.env` e o `oauth-token.json` sao SEGREDOS. Se alguem os tiver, pode usar o teu Google. Nao os partilhes.
>
> **Boa noticia:** a tua Belz atualiza-se sozinha! Sempre que a Isabel lancar novidades, ela puxa-as automaticamente de madrugada e avisa-te aqui no Telegram. Em VPS reinicia sozinha; no PC e so fechares e abrires. Tambem podes escrever _/atualizar_ quando quiseres.

**Nota para o agente (auto-update):** o codigo ja traz auto-update embutido (cron 4h + verificacao no arranque + comando `/atualizar`). Funciona porque o codigo foi instalado via `git clone` e, na VPS, corre sob PM2 (reinicio automatico). Nao e preciso configurar nada — ja vem ligado.

---

## FASE 11 — Organizar documentos (opcional, mas e o melhor!)

Depois da Belz estar a responder, mostra a aluna esta funcionalidade. Envia-lhe algo assim:

> Agora o melhor: a tua Belz tambem te organiza os documentos! 📂
>
> No Telegram, escreve **/documentos**. Ela vai perguntar-te 3 coisas:
>
> 1. **O nome da pasta** onde quer guardar tudo (ex: "Os Meus Documentos")
> 2. **As categorias** que queres, separadas por virgula (ex: _Banco, Estado, Fornecedores, Vendas_) — ou escreve "sugere" e ela poe estas 4
> 3. Se queres tambem **organizar por mes** (sim/nao)
>
> Ela cria sozinha essa pasta e as subpastas no teu Google Drive.
>
> A partir dai, sempre que tirares uma foto a uma fatura, recibo ou carta (ou enviares o PDF), mandas para a Belz no Telegram. Ela le, percebe o que e, e guarda na pasta certa. Nunca mais andas a procura de papeis! 🎉

**Notas para o agente:**

- A organizacao de documentos usa o mesmo acesso ao Drive que ja foi autorizado no OAuth (scope `drive.file`). Nao e preciso configurar mais nada.
- A Belz so consegue ver/usar pastas que ELA propria criou (e isso que `drive.file` permite) — por isso a aluna deve deixar a Belz criar a pasta, em vez de apontar para uma pasta que ja tinha.
- A config dos documentos fica em `doc-config.json` (local, nao vai para o GitHub). Para mudar categorias, basta escrever `/documentos` outra vez.

---

## TROUBLESHOOTING — erros comuns

**"Token OAuth nao encontrado"** → `npm run setup` no PC primeiro.

**"App nao verificada" no browser** → Avancado → Continuar. E normal, a app e da propria aluna.

**"Quota exceeded" Gemini** → key foi criada num projeto sem billing. Voltar a Fase 3 e criar key num projeto com billing.

**"403 access_denied" Google** → o email da aluna nao foi adicionado como Test User na Fase 5. Voltar la.

**Belz nao responde no Telegram** → ver se o `npm start` esta a correr. Se na VPS, `pm2 logs belz`. Verificar token no `.env`.

**Polling error 401** → token Telegram errado no `.env`. Voltar ao BotFather, `/mybots` → escolher bot → API token.

**"redirect_uri_mismatch"** → o cliente OAuth tem de ser tipo "Desktop app", nao "Web". Recriar na Fase 6.

---

## ATUALIZAR UMA BELZ QUE JA EXISTE (primeira vez)

Para alunas que JA tinham a Belz a correr antes do auto-update existir. So precisam
de fazer isto UMA vez — a partir dai a Belz atualiza-se sozinha.

Pergunta primeiro onde a Belz dela corre (PC ou VPS) e da o bloco certo.

**No PC:**

```bash
cd ~/minha-belz && git pull && npm install
```

Depois fecha a Belz (Ctrl+C no terminal onde corre) e arranca de novo: `npm start`.

**Na VPS:**

```bash
ssh root@<IP> "cd /root/minha-belz && git pull && npm install && pm2 restart belz"
```

Depois confirma que arrancou: `ssh root@<IP> "pm2 logs belz --lines 15 --nostream"`.

Se o `git pull` der erro de "local changes", a aluna mexeu nos ficheiros. Nesse caso:
`git stash && git pull && npm install` (guarda as alteracoes dela de lado).

Quando terminar, diz a aluna para escrever **/start** no Telegram e experimentar
o **/documentos** — ja tem a organizacao de documentos e o auto-update.

---

## NOTAS PARA O AGENTE

- **Sempre 1 passo por mensagem.** Nunca despejar varios. A aluna nao e tecnica.
- **Confirma cada passo** antes de avancar. Aceita "feito", "ok", "pronto", "ja fiz".
- **Se a aluna ficar perdida**, repete o passo com mais detalhe ou oferece-te para ver um print que ela envie.
- **NAO presumas** valores. Se o token Telegram nao parece valido, pede para colar de novo.
- **Guarda os valores em memoria interna durante a conversa** — nao em ficheiro ate ao fim, e quando escreveres o `.env`, NUNCA imprimas os secrets de volta para a aluna.
- **No final, lembra-te de deletar o `.env` temporario do `/tmp` se usaste** (caso VPS).
- **Foco PT-PT.** A Isabel e portuguesa, mentoradas tambem.
